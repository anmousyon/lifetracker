''' lifetracker app '''

from .lifetracker import app
